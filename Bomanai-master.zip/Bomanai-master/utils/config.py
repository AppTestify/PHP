BASE_URL = "https://qa.boman.ai/login"
TIMEOUT = 10
TEST_DATA_PATH = "tests/data/test_data.json"
