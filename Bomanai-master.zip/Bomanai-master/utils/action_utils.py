from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException, TimeoutException, ElementClickInterceptedException, UnexpectedAlertPresentException
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import Select
from utils.logger import logger
from datetime import datetime
import os
import time


class ActionUtils:
    logger = logger

    @staticmethod
    def click(driver, by, locator, element_name):
        try:
            logger.info(f"Clicking {element_name}")
            WebDriverWait(driver, 15).until(EC.element_to_be_clickable((by, locator))).click()
        except Exception as e:
            logger.error(f"Failed to click {element_name}: {str(e)}")
            ActionUtils.take_screenshot(driver, f"error_clicking_{element_name}")
            raise

    @staticmethod
    def enter_text(driver, by, locator, text, element_name):
        try:
            logger.info(f"Entering text '{text}' into {element_name}")
            element = WebDriverWait(driver, 15).until(EC.presence_of_element_located((by, locator)))
            element.clear()
            element.send_keys(text)
        except Exception as e:
            logger.error(f"Failed to enter text into {element_name}: {str(e)}")
            ActionUtils.take_screenshot(driver, f"error_entering_text_{element_name}")
            raise

    @staticmethod
    def select_dropdown(driver, by, locator, text, element_name):
        try:
            logger.info(f"Selecting '{text}' from {element_name}")
            dropdown = WebDriverWait(driver, 15).until(EC.presence_of_element_located((by, locator)))
            dropdown.find_element(By.XPATH, f"//option[text()='{text}']").click()
        except Exception as e:
            logger.error(f"Failed to select '{text}' from {element_name}: {str(e)}")
            ActionUtils.take_screenshot(driver, f"error_selecting_dropdown_{element_name}")
            raise

    @staticmethod
    def verify_text(driver, by, locator, expected_text, element_name):
        try:
            logger.info(f"Verifying text for {element_name}")
            actual_text = WebDriverWait(driver, 15).until(EC.presence_of_element_located((by, locator))).text
            result = expected_text in actual_text
            logger.info(f"Verification result for {element_name}: {result}")
            return actual_text
        except Exception as e:
            logger.error(f"Failed to verify text for {element_name}: {str(e)}")
            ActionUtils.take_screenshot(driver, f"error_verifying_text_{element_name}")
            raise

    @staticmethod
    def is_displayed(driver, by, locator, element_name):
        try:
            logger.info(f"Checking if {element_name} is displayed")
            displayed = WebDriverWait(driver, 15).until(EC.presence_of_element_located((by, locator))).is_displayed()
            logger.info(f"{element_name} displayed: {displayed}")
            return displayed
        except Exception as e:
            logger.error(f"Failed to check if {element_name} is displayed: {str(e)}")
            ActionUtils.take_screenshot(driver, f"error_checking_display_{element_name}")
            raise

    @staticmethod
    def take_screenshot(driver, name):
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        screenshot_name = f"screenshots/{name}_{timestamp}.png"
        driver.save_screenshot(screenshot_name)
        logger.info(f"Screenshot saved as {screenshot_name}")

    @staticmethod
    def wait_for_element(driver, by, locator, element_name, timeout=15):
        try:
            element = WebDriverWait(driver, timeout).until(EC.visibility_of_element_located((by, locator)))
            ActionUtils.logger.info(f"Found element {element_name} with locator: {locator}")
            return element
        except TimeoutException:
            ActionUtils.logger.error(
                f"Element {element_name} with locator {locator} not found within {timeout} seconds")
            raise TimeoutException(f"Element {element_name} with locator {locator} not found within {timeout} seconds")

    @staticmethod
    def get_element_text(driver, by, locator, element_name, timeout=15):
        try:
            element = ActionUtils.wait_for_element(driver, by, locator, element_name, timeout)
            text = element.text
            ActionUtils.logger.info(f"Got text from element {element_name} with locator: {locator}")
            return text
        except NoSuchElementException:
            ActionUtils.logger.error(f"Element {element_name} with locator {locator} not found")
            raise NoSuchElementException(f"Element {element_name} with locator {locator} not found")

    @staticmethod
    def is_element_displayed(driver, by, locator, element_name, timeout=15):
        try:
            element = WebDriverWait(driver, timeout).until(EC.visibility_of_element_located((by, locator)))
            displayed = element.is_displayed()
            ActionUtils.logger.info(
                f"Element '{element_name}' with locator: {locator} is {'displayed' if displayed else 'not displayed'}")
            return displayed
        except TimeoutException:
            ActionUtils.logger.error(
                f"Element '{element_name}' with locator: {locator} not found within {timeout} seconds")
            return False

    @staticmethod
    def get_elements(driver, by, locator, timeout=15):
        try:
            WebDriverWait(driver, timeout).until(EC.visibility_of_any_elements_located((by, locator)))
            elements = driver.find_elements(by, locator)
            ActionUtils.logger.info(f"Found elements with locator: {locator}")
            return elements
        except TimeoutException:
            ActionUtils.logger.error(f"Elements with locator {locator} not found within {timeout} seconds")
            raise TimeoutException(f"Elements with locator {locator} not found within {timeout} seconds")

    @staticmethod
    def set_implicit_wait(driver, time_in_seconds):
        driver.implicitly_wait(time_in_seconds)
        ActionUtils.logger.info(f"Set implicit wait to {time_in_seconds} seconds")

    @staticmethod
    def click_element_js(driver, by, locator, element_name=""):
        try:
            element = WebDriverWait(driver, 15).until(EC.visibility_of_element_located((by, locator)))
            driver.execute_script("arguments[0].scrollIntoView(true);", element)
            driver.execute_script("arguments[0].click();", element)
            logger.info(f"Clicked on element using JS: {element_name}")
        except Exception as e:
            logger.error(f"Failed to click on element using JS: {element_name}. Error: {str(e)}")
            raise

    @staticmethod
    def double_click_element(driver, by, locator, element_name):
        try:
            element = ActionUtils.wait_for_element(driver, by, locator, element_name)
            driver.execute_script("arguments[0].scrollIntoView(true);", element)
            ActionChains(driver).double_click(element).perform()
            ActionUtils.logger.info(f"Double clicked on element: {element_name}")
        except Exception as e:
            ActionUtils.logger.error(f"Failed to double click on element: {element_name}. Error: {str(e)}")
            raise e

    @staticmethod
    def toggle_checkbox_js(driver, by, locator, element_name):
        try:
            checkbox = ActionUtils.wait_for_element(driver, by, locator, element_name)
            driver.execute_script("arguments[0].click();", checkbox)
            driver.execute_script("arguments[0].click();", checkbox)
            if not checkbox.is_selected():
                driver.execute_script("arguments[0].click();", checkbox)
            ActionUtils.logger.info(f"Toggled checkbox using JS: {element_name}")
        except Exception as e:
            ActionUtils.logger.error(f"Failed to toggle checkbox: {element_name}. Error: {str(e)}")
            raise e

    @staticmethod
    def execute_js_script(driver, script, *args):
        try:
            result = driver.execute_script(script, *args)
            ActionUtils.logger.info(f"Executed JS script: {script}")
            return result
        except Exception as e:
            ActionUtils.logger.error(f"Error executing JavaScript: {str(e)}")
            raise e

    @staticmethod
    def set_slider_value(driver, by, locator, value, element_name):
        try:
            slider = ActionUtils.wait_for_element(driver, by, locator, element_name)
            driver.execute_script("arguments[0].value = arguments[1]; arguments[0].dispatchEvent(new Event('input'));", slider, value)
            ActionUtils.logger.info(f"Set slider value for {element_name} to {value}")
        except NoSuchElementException:
            ActionUtils.logger.error(f"Slider with locator {locator} not found")
            raise NoSuchElementException(f"Slider with locator {locator} not found")

    @staticmethod
    def select_from_dropdown(driver, by, locator, value, element_name, timeout=15):
        try:
            dropdown = WebDriverWait(driver, timeout).until(EC.presence_of_element_located((by, locator)))
            select = Select(dropdown)
            select.select_by_visible_text(value)
            logger.info(f"Selected '{value}' from dropdown: {element_name}")
        except NoSuchElementException:
            logger.error(f"Dropdown with locator {locator} not found")
            raise NoSuchElementException(f"Dropdown with locator {locator} not found")
        except Exception as e:
            logger.error(f"Error selecting '{value}' from dropdown {locator}: {str(e)}")
            raise e

    @staticmethod
    def scroll_to_element_and_click(driver, by, locator, element_name, timeout=15):
        try:
            element = ActionUtils.wait_for_element(driver, by, locator, element_name, timeout)
            driver.execute_script("arguments[0].scrollIntoView(true);", element)
            WebDriverWait(driver, timeout).until(EC.element_to_be_clickable((by, locator)))
            element.click()
            ActionUtils.logger.info(f"Scrolled to and clicked element: {element_name}")
        except (NoSuchElementException, TimeoutException, ElementClickInterceptedException) as e:
            ActionUtils.logger.error(f"Error while scrolling to and clicking element: {str(e)}")
            raise e

    @staticmethod
    def get_element_css_value(driver, by, locator, css_property, element_name, timeout=15):
        try:
            element = ActionUtils.wait_for_element(driver, by, locator, element_name, timeout)
            css_value = element.value_of_css_property(css_property)
            ActionUtils.logger.info(f"Got CSS value '{css_property}' from element {element_name} with locator: {locator}")
            return css_value
        except NoSuchElementException:
            ActionUtils.logger.error(f"Element with locator {locator} not found")
            raise NoSuchElementException(f"Element with locator {locator} not found")

    @staticmethod
    def check_toggle_state(driver, checkbox_id):
        try:
            checkbox = driver.find_element(By.ID, checkbox_id)
            selected = checkbox.is_selected()
            ActionUtils.logger.info(f"Checkbox with ID '{checkbox_id}' is {'selected' if selected else 'not selected'}")
            return selected
        except NoSuchElementException:
            ActionUtils.logger.error(f"Checkbox with ID '{checkbox_id}' not found")
            raise NoSuchElementException(f"Checkbox with ID '{checkbox_id}' not found")

    @staticmethod
    def click_checkbox_js(driver, by, locator, element_name):
        try:
            checkbox = ActionUtils.wait_for_element(driver, by, locator, element_name)
            driver.execute_script("arguments[0].scrollIntoView(true);", checkbox)
            driver.execute_script("arguments[0].click();", checkbox)
            ActionUtils.logger.info(f"Clicked on checkbox using JS: {element_name}")
        except Exception as e:
            ActionUtils.logger.error(f"Failed to click on checkbox using JS: {element_name}. Error: {str(e)}")
            raise e

    @staticmethod
    def select_from_dropdown_by_visible_text(driver, by, locator, text, element_name, timeout=15):
        try:
            element = ActionUtils.wait_for_element(driver, by, locator, element_name, timeout)
            select = Select(element)
            select.select_by_visible_text(text)
            ActionUtils.logger.info(f"Selected '{text}' from dropdown with locator: {locator}")
        except Exception as e:
            ActionUtils.logger.error(f"Error selecting '{text}' from dropdown {locator}: {str(e)}")
            raise

    @staticmethod
    def get_downloaded_file_name(expected_file_name, download_path="C:/Users/conta/Downloads", timeout=30):
        logger.info(f"Waiting for file '{expected_file_name}' to be downloaded in directory: {download_path}")
        end_time = time.time() + timeout

        while True:
            try:
                files = os.listdir(download_path)
                files = [os.path.join(download_path, file) for file in files]
                files.sort(key=os.path.getmtime, reverse=True)
                for file in files:
                    if os.path.basename(file) == expected_file_name:
                        logger.info(f"Downloaded file found: {file}")
                        return os.path.basename(file)
            except Exception as e:
                logger.error(f"Error while getting downloaded file name: {str(e)}")
                raise

            time.sleep(1)
            if time.time() > end_time:
                break

        logger.error(f"No file named '{expected_file_name}' was downloaded within the specified timeout")
        raise TimeoutException(f"No file named '{expected_file_name}' was downloaded within the specified timeout")

    @staticmethod
    def verify_yaml_file_content(file_path, expected_content):
        try:
            with open(file_path, 'r') as file:
                content = file.read()
                for key, value in expected_content.items():
                    assert f"{key}: {value}" in content, f"Expected {key}: {value} not found in the file"
            ActionUtils.logger.info(f"Verified YAML file content at {file_path}")
        except Exception as e:
            ActionUtils.logger.error(f"Error verifying YAML file content: {str(e)}")
            raise e

    @staticmethod
    def download_file(driver, by, locator, element_name):
        try:
            ActionUtils.click(driver, by, locator, element_name)
            time.sleep(5)  # Wait for the file to download
            ActionUtils.logger.info(f"File downloaded successfully")
        except Exception as e:
            ActionUtils.logger.error(f"Error downloading file: {str(e)}")
            raise e

    @staticmethod
    def wait_for_file_to_download(expected_file_name, download_path="C:/Users/Admin/Downloads", timeout=30):
        ActionUtils.logger.info(
            f"Waiting for file '{expected_file_name}' to be downloaded in directory: {download_path}")
        end_time = time.time() + timeout
        while True:
            try:
                files = os.listdir(download_path)
                if expected_file_name in files:
                    ActionUtils.logger.info(f"Downloaded file '{expected_file_name}' found")
                    return os.path.join(download_path, expected_file_name)
            except Exception as e:
                ActionUtils.logger.error(f"Error while checking for downloaded file: {str(e)}")
                raise e

            time.sleep(1)
            if time.time() > end_time:
                break

        ActionUtils.logger.error(f"No file named '{expected_file_name}' was downloaded within the specified timeout")
        raise TimeoutException(f"No file named '{expected_file_name}' was downloaded within the specified timeout")

    @staticmethod
    def get_error_message(driver, by, locator, element_name, timeout=15):
        try:
            element = ActionUtils.wait_for_element(driver, by, locator, element_name, timeout)
            message = element.text
            ActionUtils.logger.info(f"Got error message from element {element_name}: {message}")
            return message
        except NoSuchElementException:
            ActionUtils.logger.error(f"Error message with locator {locator} not found")
            raise NoSuchElementException(f"Error message with locator {locator} not found")

    @staticmethod
    def verify_toast_message(driver, expected_message, timeout=15):
        try:
            toast_element = WebDriverWait(driver, timeout).until(
                EC.visibility_of_element_located((By.XPATH, "//div[contains(@class, 'toast-error')]"))
            )
            actual_message = toast_element.text.strip()
            assert expected_message in actual_message, f"Expected message: '{expected_message}', but found: '{actual_message}'"
            ActionUtils.logger.info(f"Verified toast message: {actual_message}")
        except Exception as e:
            ActionUtils.logger.error(f"Failed to verify toast message: {str(e)}")
            raise

    @staticmethod
    def select_pipeline_options(driver, options):
        for option in options:
            try:
                checkbox_locator = (
                    By.XPATH, f"//label[contains(text(), '{option}')]/preceding-sibling::input[@type='checkbox']")
                ActionUtils.click(driver, By.XPATH, checkbox_locator, f"Pipeline Option {option}")
                ActionUtils.logger.info(f"Selected pipeline option: {option}")
            except Exception as e:
                ActionUtils.logger.error(f"Error selecting pipeline option '{option}': {str(e)}")
                raise e

    @staticmethod
    def uncheck_checkbox(driver, by, locator, element_name):
        try:
            checkbox = ActionUtils.wait_for_element(driver, by, locator, element_name)
            if checkbox.is_selected():
                checkbox.click()
                ActionUtils.logger.info(f"Unchecked checkbox with locator: {locator}")
            else:
                ActionUtils.logger.info(f"Checkbox with locator: {locator} is already unchecked")
        except Exception as e:
            ActionUtils.logger.error(f"Failed to uncheck checkbox with locator: {locator}. Error: {str(e)}")
            raise e

    @staticmethod
    def check_checkbox(driver, by, locator, element_name):
        try:
            checkbox = ActionUtils.wait_for_element(driver, by, locator, element_name)
            if not checkbox.is_selected():
                checkbox.click()
                ActionUtils.logger.info(f"Checked checkbox with locator: {locator}")
            else:
                ActionUtils.logger.info(f"Checkbox with locator: {locator} is already checked")
        except Exception as e:
            ActionUtils.logger.error(f"Failed to check checkbox with locator: {locator}. Error: {str(e)}")
            raise e

    @staticmethod
    def confirm_alert(driver):
        try:
            WebDriverWait(driver, 10).until(EC.alert_is_present())
            alert = driver.switch_to.alert
            alert.accept()
            ActionUtils.logger.info("Alert confirmed")
        except TimeoutException:
            ActionUtils.logger.error("No alert to confirm")
            raise TimeoutException("No alert to confirm")

    @staticmethod
    def dismiss_alert(driver, timeout=15):
        try:
            WebDriverWait(driver, timeout).until(EC.alert_is_present())
            alert = driver.switch_to.alert
            alert.dismiss()
            ActionUtils.logger.info("Alert dismissed successfully")
        except TimeoutException:
            ActionUtils.logger.error("No alert present within the specified timeout")
            raise TimeoutException("No alert present within the specified timeout")
        except UnexpectedAlertPresentException as e:
            ActionUtils.logger.error(f"Unexpected alert present: {str(e)}")
            raise e

    @staticmethod
    def upload_file(driver, by, locator, file_path, element_name):
        try:
            file_input = ActionUtils.wait_for_element(driver, by, locator, element_name)
            file_input.send_keys(file_path)
            ActionUtils.logger.info(f"Uploaded file from path: {file_path}")
        except NoSuchElementException:
            ActionUtils.logger.error(f"File input with locator {locator} not found")
            raise NoSuchElementException(f"File input with locator {locator} not found")
