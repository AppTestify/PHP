import logging
import logging.config
from datetime import datetime
from .log_config import LOGGING_CONFIG

# Add timestamp to log filename
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
LOGGING_CONFIG['handlers']['file']['filename'] = f'logs/test_log_{timestamp}.log'

logging.config.dictConfig(LOGGING_CONFIG)
logger = logging.getLogger('testLogger')
