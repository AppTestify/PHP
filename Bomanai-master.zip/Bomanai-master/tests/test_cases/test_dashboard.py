import pytest
from selenium.webdriver.remote.webdriver import WebDriver

from tests.pages import profile_page
from tests.pages.dashboard_page import DashboardPage
from tests.pages.profile_page import ProfilePage
from utils.config import TEST_DATA_PATH
from utils.data_loader import load_test_data
from utils.action_utils import ActionUtils

test_data = load_test_data(TEST_DATA_PATH)


class TestDashboard:
    driver: WebDriver

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_view_total_apps(self, driver, login):
        dashboard_page = DashboardPage(driver)
        profile_page = ProfilePage(driver)
        profile_page.open_profile_page()


    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_view_total_successful_scans(self, driver, login):
        dashboard_page = DashboardPage(driver)
        profile_page = ProfilePage(driver)
        profile_page.open_profile_page()

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_add_vulnerability_to_jira(self, driver, login):
        dashboard_page = DashboardPage(driver)
        profile_page = ProfilePage(driver)
        profile_page.open_profile_page()

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_edit_vulnerability_in_jira(self, driver, login):
        dashboard_page = DashboardPage(driver)
        profile_page = ProfilePage(driver)
        profile_page.open_profile_page()

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_quick_view_vulnerability(self, driver, login):
        dashboard_page = DashboardPage(driver)
        profile_page = ProfilePage(driver)
        profile_page.open_profile_page()

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_export_vulnerabilities_excel(self, driver, login):
        dashboard_page = DashboardPage(driver)
        profile_page = ProfilePage(driver)
        profile_page.open_profile_page()

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_export_vulnerabilities_report(self, driver, login):
        dashboard_page = DashboardPage(driver)
        profile_page = ProfilePage(driver)
        profile_page.open_profile_page()

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_navigate_back_to_findings(self, driver, login):
        dashboard_page = DashboardPage(driver)
        profile_page = ProfilePage(driver)
        profile_page.open_profile_page()

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_view_details_overlay(self, driver, login):
        dashboard_page = DashboardPage(driver)
        profile_page = ProfilePage(driver)
        profile_page.open_profile_page()

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_verify_solution_page(self, driver, login):
        dashboard_page = DashboardPage(driver)
        profile_page = ProfilePage(driver)
        profile_page.open_profile_page()
