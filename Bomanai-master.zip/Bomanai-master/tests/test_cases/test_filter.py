import pytest
from selenium.webdriver.remote.webdriver import WebDriver
from tests.pages.filters_page import FiltersPage
from utils.config import TEST_DATA_PATH
from utils.data_loader import load_test_data

test_data = load_test_data(TEST_DATA_PATH)


class TestFilterAPIApplications:
    driver: WebDriver

    @pytest.mark.parametrize("login", [{"email": test_data["application_email"], "password": test_data["application_password"]}], indirect=True)
    def test_filter_api_applications(self, driver, login):
        filters_page = FiltersPage(driver)
        filters_page.open_applications_page()
        filters_page.select_filter_option("API")
        filters_page.verify_applications_filtered_by_type("API")

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_filter_desktop_applications(self, driver, login):
        filters_page = FiltersPage(driver)
        filters_page.open_applications_page()
        filters_page.select_filter_option("Desktop")
        filters_page.verify_applications_filtered_by_type("Desktop")

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_filter_mobile_applications(self, driver, login):
        filters_page = FiltersPage(driver)
        filters_page.open_applications_page()
        filters_page.select_filter_option("Mobile")
        filters_page.verify_applications_filtered_by_type("Mobile")

    @pytest.mark.parametrize("login", [{"email": test_data["valid_email"], "password": test_data["password"]}],
                             indirect=True)
    def test_filter_others_applications(self, driver, login):
        filters_page = FiltersPage(driver)
        filters_page.open_applications_page()
        filters_page.select_filter_option("Others")
        filters_page.verify_applications_filtered_by_type("Others")

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_filter_script_cli_applications(self, driver, login):
        filters_page = FiltersPage(driver)
        filters_page.open_applications_page()
        filters_page.select_filter_option("Script___CLI")
        filters_page.verify_applications_filtered_by_type("Script / CLI")

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_filter_web_applications(self, driver, login):
        filters_page = FiltersPage(driver)
        filters_page.open_applications_page()
        filters_page.select_filter_option("WEB")
        filters_page.verify_applications_filtered_by_type("WEB")

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_view_scanned_report(self, driver, login):
        filters_page = FiltersPage(driver)
        filters_page.open_applications_page()
        filters_page.select_filter_option("WEB")
        filters_page.view_latest_result()
        filters_page.apply_scan_type_filter("sast")
        filters_page.apply_severity_filter("medium")
