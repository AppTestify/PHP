import pytest
import random
import string
from selenium.webdriver.remote.webdriver import WebDriver
from tests.pages.onboard_app_page import OnboardAppPage
from utils.config import TEST_DATA_PATH
from utils.data_loader import load_test_data

test_data = load_test_data(TEST_DATA_PATH)

def generate_random_app_name(prefix: str, length: int = 8) -> str:
    """Generate a random app name with a given prefix."""
    random_str = ''.join(random.choices(string.ascii_letters + string.digits, k=length))
    return f"{prefix}_{random_str}"

class TestAddApiAppPython:
    driver: WebDriver

    @pytest.mark.parametrize("login", [{"email": test_data["valid_email"], "password": test_data["password"]}], indirect=True)
    def test_add_api_app_python(self, driver, login):
        # Perform onboard app actions after login
        onboard_app_page = OnboardAppPage(driver)
        onboard_app_page.click_onboard_app_button()

        if onboard_app_page.is_max_app_limit_reached():
            pytest.skip("Reached MAX APP limit, test skipped.")

        onboard_app_page.select_app_type("Api")
        onboard_app_page.select_language("Python")
        # onboard_app_page.configure_app()
        onboard_app_page.configure_app_slider(rate4=5, rate5=5, num6=50, num7=50)
        onboard_app_page.select_ci_cd("Github")
        random_app_name = generate_random_app_name("Api_Python_App")
        onboard_app_page.enter_app_name(random_app_name)
        onboard_app_page.agree_terms_and_finish()

        assert onboard_app_page.verify_success_message(), "Success message should be displayed"
        assert onboard_app_page.verify_download_buttons(), "Download buttons should be displayed"

    @pytest.mark.parametrize("login", [{"email": test_data["valid_email"], "password": test_data["password"]}], indirect=True)
    def test_add_mobile_app_python(self, driver, login):
        onboard_app_page = OnboardAppPage(driver)
        onboard_app_page.click_onboard_app_button()

        if onboard_app_page.is_max_app_limit_reached():
            pytest.skip("Reached MAX APP limit, test skipped.")

        onboard_app_page.select_app_type("Mobile")
        onboard_app_page.select_language("Python")
        # onboard_app_page.configure_app()
        onboard_app_page.configure_app_slider(rate4=5, rate5=5, num6=50, num7=50)
        onboard_app_page.select_ci_cd("Jenkins")
        random_app_name = generate_random_app_name("Mobile_Python_App")
        onboard_app_page.enter_app_name(random_app_name)
        onboard_app_page.agree_terms_and_finish()

        assert onboard_app_page.verify_success_message(), "Success message should be displayed"
        assert onboard_app_page.verify_download_buttons(), "Download buttons should be displayed"

    @pytest.mark.parametrize("login", [{"email": test_data["valid_email"], "password": test_data["password"]}], indirect=True)
    def test_add_web_app_dotnet(self, driver, login):
        onboard_app_page = OnboardAppPage(driver)
        onboard_app_page.click_onboard_app_button()

        if onboard_app_page.is_max_app_limit_reached():
            pytest.skip("Reached MAX APP limit, test skipped.")

        onboard_app_page.select_app_type("Web")
        onboard_app_page.select_language(".Net")
        # onboard_app_page.configure_app()
        onboard_app_page.configure_app_slider(rate4=5, rate5=5, num6=50, num7=50)
        onboard_app_page.select_ci_cd("Github")
        random_app_name = generate_random_app_name("Web_DotNet_App")
        onboard_app_page.enter_app_name(random_app_name)
        onboard_app_page.agree_terms_and_finish()

        assert onboard_app_page.verify_success_message(), "Success message should be displayed"
        assert onboard_app_page.verify_download_buttons(), "Download buttons should be displayed"

    @pytest.mark.parametrize("login", [{"email": test_data["valid_email"], "password": test_data["password"]}], indirect=True)
    def test_add_web_app_java(self, driver, login):
        onboard_app_page = OnboardAppPage(driver)
        onboard_app_page.click_onboard_app_button()

        if onboard_app_page.is_max_app_limit_reached():
            pytest.skip("Reached MAX APP limit, test skipped.")

        onboard_app_page.select_app_type("Web")
        onboard_app_page.select_language("Java")
        # onboard_app_page.configure_app()
        onboard_app_page.configure_app_slider(rate4=5, rate5=5, num6=50, num7=50)
        onboard_app_page.select_ci_cd("Others")
        random_app_name = generate_random_app_name("Web_Java_App")
        onboard_app_page.enter_app_name(random_app_name)
        onboard_app_page.agree_terms_and_finish()

        assert onboard_app_page.verify_success_message(), "Success message should be displayed"
        assert onboard_app_page.verify_download_buttons(), "Download buttons should be displayed"

    @pytest.mark.parametrize("login", [{"email": test_data["valid_email"], "password": test_data["password"]}], indirect=True)
    def test_add_web_app_nodejs(self, driver, login):
        onboard_app_page = OnboardAppPage(driver)
        onboard_app_page.click_onboard_app_button()

        if onboard_app_page.is_max_app_limit_reached():
            pytest.skip("Reached MAX APP limit, test skipped.")

        onboard_app_page.select_app_type("Web")
        onboard_app_page.select_language("NodeJS")
        # onboard_app_page.configure_app()
        onboard_app_page.configure_app_slider(rate4=5, rate5=5, num6=50, num7=50)
        onboard_app_page.select_ci_cd("Others")
        random_app_name = generate_random_app_name("Web_NodeJS_App")
        onboard_app_page.enter_app_name(random_app_name)
        onboard_app_page.agree_terms_and_finish()

        assert onboard_app_page.verify_success_message(), "Success message should be displayed"
        assert onboard_app_page.verify_download_buttons(), "Download buttons should be displayed"

    @pytest.mark.parametrize("login", [{"email": test_data["valid_email"], "password": test_data["password"]}], indirect=True)
    def test_add_web_app_php(self, driver, login):
        onboard_app_page = OnboardAppPage(driver)
        onboard_app_page.click_onboard_app_button()

        if onboard_app_page.is_max_app_limit_reached():
            pytest.skip("Reached MAX APP limit, test skipped.")

        onboard_app_page.select_app_type("Web")
        onboard_app_page.select_language("PHP")
        # onboard_app_page.configure_app()
        onboard_app_page.configure_app_slider(rate4=5, rate5=5, num6=50, num7=50)
        onboard_app_page.select_ci_cd("Gitlab")
        random_app_name = generate_random_app_name("Web_Php_App")
        onboard_app_page.enter_app_name(random_app_name)
        onboard_app_page.agree_terms_and_finish()

        assert onboard_app_page.verify_success_message(), "Success message should be displayed"
        assert onboard_app_page.verify_download_buttons(), "Download buttons should be displayed"

    @pytest.mark.parametrize("login", [{"email": test_data["valid_email"], "password": test_data["password"]}], indirect=True)
    def test_add_web_app_others(self, driver, login):
        onboard_app_page = OnboardAppPage(driver)
        onboard_app_page.click_onboard_app_button()

        if onboard_app_page.is_max_app_limit_reached():
            pytest.skip("Reached MAX APP limit, test skipped.")

        onboard_app_page.select_app_type("Web")
        onboard_app_page.select_language("Others")
        # onboard_app_page.configure_app()
        onboard_app_page.configure_app_slider(rate4=5, rate5=5, num6=50, num7=50)
        onboard_app_page.select_ci_cd("Github")
        random_app_name = generate_random_app_name("Web_Others_App")
        onboard_app_page.enter_app_name(random_app_name)
        onboard_app_page.agree_terms_and_finish()

        assert onboard_app_page.verify_success_message(), "Success message should be displayed"
        assert onboard_app_page.verify_download_buttons(), "Download buttons should be displayed"

    @pytest.mark.parametrize("login", [{"email": test_data["valid_email"], "password": test_data["password"]}], indirect=True)
    def test_onboard_app_error_validation(self, driver, login):
        onboard_app_page = OnboardAppPage(driver)
        onboard_app_page.click_onboard_app_button()

        if onboard_app_page.is_max_app_limit_reached():
            pytest.skip("Reached MAX APP limit, test skipped.")

        # Step 1 - Error Validation
        onboard_app_page.click_next()
        onboard_app_page.verify_step1_error_message()

        # Provide necessary details to pass Step 1
        onboard_app_page.select_app_type("Web")

        # Step 2 - Error Validation
        onboard_app_page.click_next_tech()
        onboard_app_page.verify_step2_error_message()

        # Provide necessary details to pass Step 2
        onboard_app_page.select_language("PHP")

        # Step 3 - Error Validation
        onboard_app_page.click_next_selectapp()
        onboard_app_page.verify_step3_error_message()

        # Provide necessary details to pass Step 3
        onboard_app_page.configure_app_slider(rate4=5, rate5=5, num6=50, num7=50)

        # Done Step - Error Validation
        onboard_app_page.click_finish_button()
        onboard_app_page.verify_done_step_error_messages()
