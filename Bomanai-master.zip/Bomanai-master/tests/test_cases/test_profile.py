import pytest
from selenium.webdriver.remote.webdriver import WebDriver
from tests.pages.profile_page import ProfilePage
from utils.config import TEST_DATA_PATH
from utils.data_loader import load_test_data
from utils.action_utils import ActionUtils

test_data = load_test_data(TEST_DATA_PATH)


class TestProfile:
    driver: WebDriver

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_delete_user(self, driver, login):
        profile_page = ProfilePage(driver)
        profile_page.open_profile_page()


    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_add_user_existing_email(self, driver, login):
        profile_page = ProfilePage(driver)
        profile_page.open_profile_page()

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_add_user(self, driver, login):
        profile_page = ProfilePage(driver)
        profile_page.open_profile_page()

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_mismatch_password(self, driver, login):
        profile_page = ProfilePage(driver)
        profile_page.open_profile_page()

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_change_password(self, driver, login):
        profile_page = ProfilePage(driver)
        profile_page.open_profile_page()

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_update_profile_info(self, driver, login):
        profile_page = ProfilePage(driver)
        profile_page.open_profile_page()
