import pytest
from selenium.webdriver.remote.webdriver import WebDriver
from tests.pages.onboard_app_page import OnboardAppPage
from utils.config import TEST_DATA_PATH
from utils.data_loader import load_test_data

test_data = load_test_data(TEST_DATA_PATH)


class TestAddApiAppPython:
    driver: WebDriver

    @pytest.mark.parametrize("login", [{"email": test_data["valid_email"], "password": test_data["password"]}], indirect=True)
    def test_onboard_app_error(self, driver, login):
        onboard_app_page = OnboardAppPage(driver)
        onboard_app_page.click_onboard_app_button()

        if onboard_app_page.is_max_app_limit_reached():
            pytest.skip("Reached MAX APP limit, test skipped.")

        # Step 1 - Error Validation
        onboard_app_page.click_next()
        onboard_app_page.verify_step1_error_message()

        # Provide necessary details to pass Step 1
        onboard_app_page.select_app_type("Web")

        # Step 2 - Error Validation
        onboard_app_page.click_next_tech()
        onboard_app_page.verify_step2_error_message()

        # Provide necessary details to pass Step 2
        onboard_app_page.select_language("PHP")

        # Step 3 - Error Validation
        onboard_app_page.click_next_selectapp()
        onboard_app_page.verify_step3_error_message()

        # Provide necessary details to pass Step 3
        onboard_app_page.configure_app_slider(rate4=5, rate5=5, num6=50, num7=50)

        # Done Step - Error Validation
        onboard_app_page.click_finish_button()
        onboard_app_page.verify_done_step_error_messages()
