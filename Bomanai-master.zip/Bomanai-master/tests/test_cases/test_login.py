from tests.pages.login_page import LoginPage
from utils.config import BASE_URL, TEST_DATA_PATH
from utils.data_loader import load_test_data

test_data = load_test_data(TEST_DATA_PATH)


def test_invalid_email_change_password(driver):
    driver.get(BASE_URL)
    login_page = LoginPage(driver)
    login_page.click_forgot_password()
    login_page.enter_email(test_data["invalid_email"])
    login_page.click_login()
    assert login_page.get_error_message() == "Email not found"


def test_enter_email_for_change_password(driver):
    driver.get(BASE_URL)
    login_page = LoginPage(driver)
    login_page.click_forgot_password()
    assert "forgot_password" in driver.current_url


def test_show_password_checkbox(driver):
    driver.get(BASE_URL)
    login_page = LoginPage(driver)
    login_page.enter_email(test_data["valid_email"])
    login_page.check_show_password()
    login_page.enter_password(test_data["password"])
    assert driver.find_element(*LoginPage.PASSWORD_INPUT).get_attribute("type") == "text"


def test_invalid_email_format(driver):
    driver.get(BASE_URL)
    login_page = LoginPage(driver)
    login_page.enter_email(test_data["short_email"])
    login_page.enter_password(test_data["password"])
    login_page.click_login()
    error_message = login_page.get_email_format_error_message()
    expected_message = "Please include an '@' in the email address. 'santosh.k' is missing an '@'."
    assert error_message == expected_message, "The error message for invalid email format should be displayed"


def test_login_with_valid_credentials(driver):
    driver.get(BASE_URL)
    login_page = LoginPage(driver)
    login_page.enter_email(test_data["valid_email"])
    login_page.enter_password(test_data["password"])
    login_page.click_login()
    assert "dashboard" in driver.current_url


def test_hover_over_forgot_password(driver):
    driver.get(BASE_URL)
    login_page = LoginPage(driver)

    # Perform hover action and verify color change
    color = login_page.hover_over_forgot_password()
    expected_color = 'rgba(32, 201, 151, 1)'
    assert color == expected_color, f"Expected color to be green but got {color}"