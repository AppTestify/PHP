import pytest
from selenium.webdriver.remote.webdriver import WebDriver
from tests.pages.application_page import ApplicationPage
from tests.pages.onboard_app_page import OnboardAppPage
from utils.action_utils import ActionUtils
from utils.config import TEST_DATA_PATH
from utils.data_loader import load_test_data
from datetime import datetime

test_data = load_test_data(TEST_DATA_PATH)


class TestGetCiCdConfigAzure:
    driver: WebDriver

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_get_ci_cd_config_azure(self, driver, login):
        application_page = ApplicationPage(driver)

        # Navigate to Applications page
        application_page.navigate_to_applications_page()
        app_name = "test"
        application_page.verify_application_present(app_name)

        # Get CI/CD config for Azure
        application_page.get_ci_cd_config(app_name, "Azure")
        expected_file_name = "azure-pipelines.yml"
        downloaded_file_name = ActionUtils.get_downloaded_file_name(expected_file_name)
        assert downloaded_file_name == expected_file_name, f"Expected file name: {expected_file_name}, but found: {downloaded_file_name}"


    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_get_ci_cd_config_github_actions(self, driver, login):
        application_page = ApplicationPage(driver)

        # Navigate to Applications page
        application_page.navigate_to_applications_page()
        app_name = "test"
        application_page.verify_application_present(app_name)

        # Get CI/CD config for GitHub Actions
        application_page.get_ci_cd_config(app_name, "Github Actions")
        expected_file_name = "github.yaml"
        downloaded_file_name = ActionUtils.get_downloaded_file_name(expected_file_name)
        assert downloaded_file_name == expected_file_name, f"Expected file name: {expected_file_name}, but found: {downloaded_file_name}"

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_get_ci_cd_config_gitlab(self, driver, login):
        application_page = ApplicationPage(driver)

        # Navigate to Applications page
        application_page.navigate_to_applications_page()
        app_name = "test"
        application_page.verify_application_present(app_name)

        # Get CI/CD config for Gitlab
        application_page.get_ci_cd_config(app_name, "Gitlab CI/CD")
        expected_file_name = "gitlab-ci.yaml"
        downloaded_file_name = ActionUtils.get_downloaded_file_name(expected_file_name)
        assert downloaded_file_name == expected_file_name, f"Expected file name: {expected_file_name}, but found: {downloaded_file_name}"

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_get_ci_cd_config_jenkins(self, driver, login):
        application_page = ApplicationPage(driver)

        # Navigate to Applications page
        application_page.navigate_to_applications_page()
        app_name = "AOL Tester"
        application_page.verify_application_present(app_name)

        # Get CI/CD config for Jenkins
        application_page.get_ci_cd_config(app_name, "Jenkins")
        expected_file_name = "jenkinsfile"
        downloaded_file_name = ActionUtils.get_downloaded_file_name(expected_file_name)
        assert downloaded_file_name == expected_file_name, f"Expected file name: {expected_file_name}, but found: {downloaded_file_name}"

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_configure_boman_application_dast(self, driver, login):
        application_page = ApplicationPage(driver)

        # Navigate to Applications page
        application_page.navigate_to_applications_page()
        app_name = "test_1"
        application_page.verify_application_present(app_name)

        # Create Boman Config
        application_page.open_application_menu(app_name)
        application_page.select_create_boman_config()

        # Select Default pipeline checkbox as DAST
        application_page.check_dast_checkbox()
        dast_url = "https://demo.testfire.net/"
        application_page.enter_dast_url(dast_url)

        # Click Generate & Download
        application_page.click_generate_and_download()

        # Verify downloaded file
        expected_file_name = "boman.yaml"
        application_page.verify_download_file_name(expected_file_name)

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_configure_sca_secret_scanning(self, driver, login):
        application_page = ApplicationPage(driver)

        # Navigate to Applications page
        application_page.navigate_to_applications_page()
        app_name = "test_1"
        application_page.verify_application_present(app_name)

        # Create Boman Config
        application_page.open_application_menu(app_name)
        application_page.select_create_boman_config()

        # Select Default pipeline checkboxes
        application_page.uncheck_sast_checkbox()
        application_page.check_secret_scanning_checkbox()

        # Click Generate & Download
        application_page.click_generate_and_download()

        # Verify downloaded file
        expected_file_name = "boman.yaml"
        application_page.verify_download_file_name(expected_file_name)

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_configure_boman_application_without_dast_url(self, driver, login):
        application_page = ApplicationPage(driver)

        # Navigate to Applications page
        application_page.navigate_to_applications_page()
        app_name = "test_1"
        application_page.verify_application_present(app_name)

        # Create Boman Config
        application_page.open_application_menu(app_name)
        application_page.select_create_boman_config()

        # Select Default pipeline checkbox as DAST
        application_page.check_dast_checkbox()

        # Do not add the URL and click Generate & Download
        application_page.click_generate_and_download()

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_application_details(self, driver, login):
        application_page = ApplicationPage(driver)

        # Navigate to Applications page
        application_page.navigate_to_applications_page()
        app_name = "test"
        application_page.verify_application_present(app_name)

        # Verify application details
        # expected_creation_date = "Created on May 29, 2024"
        # expected_type = "WEB"
        # expected_technology = "python"
        # expected_scan_count = 0
        # expected_last_scan = "Jun 17, 2024"
        #
        # application_page.verify_creation_date(expected_creation_date)
        # application_page.verify_application_type(expected_type)
        # application_page.verify_technology(expected_technology)
        # application_page.verify_no_of_scans(expected_scan_count)
        # application_page.verify_last_scan(expected_last_scan)

    @pytest.mark.parametrize("login", [{"email": test_data["valid_email"], "password": test_data["password"]}],
                             indirect=True)
    def test_verify_application_added(self, driver, login):
        onboard_app_page = OnboardAppPage(driver)
        application_page = ApplicationPage(driver)

        # Onboard an application
        onboard_app_page.click_onboard_app_button()

        if onboard_app_page.is_max_app_limit_reached():
            pytest.skip("Reached MAX APP limit, test skipped.")

        onboard_app_page.select_app_type("Web")
        onboard_app_page.select_language(".Net")
        onboard_app_page.configure_app_slider(rate4=5, rate5=5, num6=50, num7=50)
        onboard_app_page.select_ci_cd("Github")
        app_name = "Test_Web_Others_App17"
        onboard_app_page.enter_app_name(app_name)
        onboard_app_page.agree_terms_and_finish()

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_view_all_scans(self, driver, login):
        application_page = ApplicationPage(driver)

        # Navigate to Applications page
        application_page.navigate_to_applications_page()
        app_name = "test_1"
        application_page.verify_application_present(app_name)

        # View all scans of the application
        application_page.view_all_scans(app_name)
        application_page.verify_no_scan_found_message()

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_view_latest_scan_results(self, driver, login):
        application_page = ApplicationPage(driver)

        # Navigate to Applications page
        application_page.navigate_to_applications_page()
        app_name = "test_1"
        application_page.verify_application_present(app_name)

        # View all scans of the application
        application_page.view_all_scans(app_name)
        application_page.verify_no_scan_found_message()

        # # Verify number of scans
        # expected_scan_count = "5"
        # application_page.verify_scan_count(expected_scan_count)
        #
        # # Verify last scan date
        # expected_last_scan_date = "Initiated on Mon, 17 Jun 2024 04:47:10 UTC"
        # application_page.verify_last_scan_date(expected_last_scan_date)

        # # Expand vulnerabilities and verify status
        # application_page.expand_vulnerability()
        # expected_status = "Pending"
        # application_page.verify_vulnerability_status(expected_status)

