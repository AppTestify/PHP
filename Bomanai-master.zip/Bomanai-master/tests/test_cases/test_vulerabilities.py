import time
import pytest
from selenium.webdriver.remote.webdriver import WebDriver
from tests.pages.filters_page import FiltersPage
from tests.pages.vulnerabilities_page import VulnerabilitiesPage
from utils.config import TEST_DATA_PATH
from utils.data_loader import load_test_data
from utils.action_utils import ActionUtils

test_data = load_test_data(TEST_DATA_PATH)


@pytest.mark.usefixtures("login")
class TestVulnerabilities:
    driver: WebDriver

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_mark_all_as_fixed(self, driver, login):
        filters_page = FiltersPage(driver)
        vulnerabilities_page = VulnerabilitiesPage(driver)
        filters_page.open_applications_page()
        time.sleep(5)
        filters_page.view_latest_result()
        time.sleep(5)
        vulnerabilities_page.mark_all_as_fixed()
        time.sleep(5)
        vulnerabilities_page.verify_status()

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_mark_all_as_accepted_risk(self, driver, login):
        filters_page = FiltersPage(driver)
        vulnerabilities_page = VulnerabilitiesPage(driver)
        filters_page.open_applications_page()
        time.sleep(5)
        filters_page.view_latest_result()
        time.sleep(5)


    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_mark_all_as_in_progress(self, driver, login):
        filters_page = FiltersPage(driver)
        vulnerabilities_page = VulnerabilitiesPage(driver)
        filters_page.open_applications_page()
        time.sleep(5)
        filters_page.view_latest_result()


    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_mark_all_as_pending_fix(self, driver, login):
        filters_page = FiltersPage(driver)
        vulnerabilities_page = VulnerabilitiesPage(driver)
        filters_page.open_applications_page()
        time.sleep(5)
        filters_page.view_latest_result()

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_mark_all_as_false_positive_sast_dast(self, driver, login):
        filters_page = FiltersPage(driver)
        vulnerabilities_page = VulnerabilitiesPage(driver)
        filters_page.open_applications_page()
        time.sleep(5)
        filters_page.view_latest_result()

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_mark_all_as_false_positive_sca_secret(self, driver, login):
        filters_page = FiltersPage(driver)
        vulnerabilities_page = VulnerabilitiesPage(driver)
        filters_page.open_applications_page()
        time.sleep(5)
        filters_page.view_latest_result()
