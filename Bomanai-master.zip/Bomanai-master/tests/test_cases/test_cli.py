import pytest
from selenium.webdriver.remote.webdriver import WebDriver
from tests.pages.cli_page import CLIPage
from utils.config import TEST_DATA_PATH
from utils.data_loader import load_test_data

test_data = load_test_data(TEST_DATA_PATH)


@pytest.mark.skip(reason="Skipping this test as it's out of scope")
class TestCLI:
    driver: WebDriver

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_edit_boman_yaml_unexpected_data(self, driver, login):
        cli_page = CLIPage(driver)
        cli_page.open_cli_page()
        cli_page.download_boman_yaml()
        # Edit the downloaded boman.yaml file with unexpected data
        cli_page.upload_boman_yaml("path_to_modified_boman.yaml")
        cli_page.trigger_scan()
        error_message = cli_page.get_error_message()
        assert "expected_error_message" in error_message, "Exception handling not properly done for unexpected data"

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_scan_with_platform_down(self, driver, login):
        cli_page = CLIPage(driver)
        cli_page.open_cli_page()
        cli_page.trigger_scan()
        error_message = cli_page.get_error_message()
        assert "platform_down_message" in error_message, "Scan should be aborted when the platform is down"

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_successful_scan_azure_devops(self, driver, login):
        cli_page = CLIPage(driver)
        cli_page.open_cli_page()
        cli_page.trigger_scan()
        scan_result = cli_page.get_scan_result()
        assert "expected_scan_result" in scan_result, "Scan was not successful for Azure DevOps configuration"

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_successful_scan_github_actions(self, driver, login):
        cli_page = CLIPage(driver)
        cli_page.open_cli_page()
        cli_page.trigger_scan()
        scan_result = cli_page.get_scan_result()
        assert "expected_scan_result" in scan_result, "Scan was not successful for GitHub Actions configuration"

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_successful_scan_gitlab(self, driver, login):
        cli_page = CLIPage(driver)
        cli_page.open_cli_page()
        cli_page.trigger_scan()
        scan_result = cli_page.get_scan_result()
        assert "expected_scan_result" in scan_result, "Scan was not successful for Gitlab configuration"

    @pytest.mark.parametrize("login",
                             [{"email": test_data["application_email"], "password": test_data["application_password"]}],
                             indirect=True)
    def test_successful_scan_jenkins(self, driver, login):
        cli_page = CLIPage(driver)
        cli_page.open_cli_page()
        cli_page.trigger_scan()
        scan_result = cli_page.get_scan_result()
        assert "expected_scan_result" in scan_result, "Scan was not successful for Jenkins configuration"
