import pytest
import os
from datetime import datetime
import matplotlib.pyplot as plt
import base64
from io import BytesIO
from utils.logger import logger
from tests.fixtures.browser import driver
from tests.pages.login_page import LoginPage
from utils.data_loader import load_test_data
from utils.config import BASE_URL, TEST_DATA_PATH

test_data = load_test_data(TEST_DATA_PATH)


@pytest.fixture(scope="session", autouse=True)
def setup_session():
    logger.info("Starting test session")
    os.makedirs('screenshots', exist_ok=True)
    os.makedirs('logs', exist_ok=True)
    os.makedirs('reports', exist_ok=True)
    yield
    logger.info("Ending test session")


@pytest.fixture(scope="function")
def login(request, driver):
    email = request.param.get('email')
    password = request.param.get('password')
    driver.get(BASE_URL)
    login_page = LoginPage(driver)
    login_page.enter_email(email)
    login_page.enter_password(password)
    login_page.click_login()


@pytest.hookimpl(tryfirst=True, hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    rep = outcome.get_result()

    if rep.when == "call" and rep.failed:
        if "driver" in item.fixturenames:
            web_driver = item.funcargs["driver"]
            test_name = item.name
            screenshot_name = f"screenshots/{test_name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
            web_driver.save_screenshot(screenshot_name)
            logger.error(f"Screenshot for {test_name} saved as {screenshot_name}")

            with open("reports/failures.html", "a") as report:
                report.write(f"<h2>Test {test_name} Failed</h2>")
                report.write(f'<img src="../{screenshot_name}" alt="screenshot" style="width:600px;"><br>\n')
                report.write(f"<p>Screenshot saved as {screenshot_name}</p>\n")
                report.write("<hr>\n")


@pytest.hookimpl(tryfirst=True, hookwrapper=True)
def pytest_sessionfinish(session, exitstatus):
    outcome = yield
    with open("reports/failures.html", "a") as report:
        report.write(f"<h2>Test Session Finished with exit status: {exitstatus}</h2>")
        report.write("<hr>\n")


@pytest.hookimpl(tryfirst=True, hookwrapper=True)
def pytest_terminal_summary(terminalreporter, exitstatus, config):
    outcome = yield

    passed = len(terminalreporter.stats.get('passed', []))
    failed = len(terminalreporter.stats.get('failed', []))
    total = passed + failed

    # Generate pie chart
    labels = 'Passed', 'Failed'
    sizes = [passed, failed]
    colors = ['green', 'red']
    explode = (0.1, 0)  # explode the first slice

    plt.pie(sizes, explode=explode, labels=labels, colors=colors, autopct='%1.1f%%', shadow=True, startangle=140)
    plt.axis('equal')  # Equal aspect ratio ensures that pie is drawn as a circle.

    # Save to a BytesIO object and encode as base64
    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    image_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    buffer.close()
    plt.close()

    with open("reports/failures.html", "a") as report:
        report.write("<h2>Test Summary</h2>")
        report.write(f"<p>Total Tests: {total}</p>")
        report.write(f"<p>Passed Tests: {passed}</p>")
        report.write(f"<p>Failed Tests: {failed}</p>")
        report.write(f'<img src="data:image/png;base64,{image_base64}" alt="pie chart" style="width:600px;"><br>\n')
        report.write("<hr>\n")
