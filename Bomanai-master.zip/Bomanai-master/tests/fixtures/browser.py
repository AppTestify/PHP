import pytest
from selenium import webdriver
from utils.logger import logger


@pytest.fixture(scope="function")
def driver():
    logger.info("Setting up WebDriver")
    driver = webdriver.Chrome()
    driver.maximize_window()
    yield driver
    driver.quit()
    logger.info("Tearing down WebDriver")
