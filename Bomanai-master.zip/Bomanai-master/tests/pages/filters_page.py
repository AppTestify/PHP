from selenium.webdriver.common.by import By
from selenium.common.exceptions import ElementClickInterceptedException
from tests.pages.base_page import BasePage
from utils.action_utils import ActionUtils
from utils.logger import logger


class FiltersPage(BasePage):
    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver
        self.logger = logger

    # Locators
    application_icon = (By.XPATH, "//a[@href='/apps']")
    filter_option = "//input[@id='search_{}']"
    app_type = "//span[contains(@class, 'badge') and contains(text(), '{}')]"
    application_name = "//a[text()='{}']"
    latest_result = "(//a[@class='card-link float-end fs-0 badge badge-sm light badge-info'])[1]"
    severity_filter = "//input[@id='{}']"
    scan_type_filter = "//input[@id='{}']"
    issue_severity = "//input[@id='{}']"
    issue_scan_type = "//input[@id='{}']"

    def open_applications_page(self):
        self.logger.info("Attempting to open applications page")
        try:
            ActionUtils.click(self.driver, *self.application_icon, "Applications Icon")
            self.logger.info("Applications page opened successfully")
        except Exception as e:
            self.logger.error(f"Failed to open applications page: {str(e)}")
            raise

    def select_filter_option(self, option):
        self.logger.info(f"Attempting to select filter option: {option}")
        try:
            option_id = option.replace(' ', '_')
            filter_locator = (By.XPATH, self.filter_option.format(option_id))
            ActionUtils.click(self.driver, *filter_locator, f"Filter Option {option}")
            self.logger.info(f"Filter option '{option}' selected successfully")
        except Exception as e:
            self.logger.error(f"Failed to select filter option '{option}': {str(e)}")
            raise

    def verify_applications_filtered_by_type(self, app_type):
        self.logger.info(f"Attempting to verify applications filtered by type: {app_type}")
        try:
            app_type_locator = (By.XPATH, self.app_type.format(app_type))
            app_type_elements = ActionUtils.get_elements(self.driver, *app_type_locator, timeout=20)
            assert app_type_elements, f"No applications found for type: {app_type}"
            for element in app_type_elements:
                assert app_type.lower() in element.text.lower(), f"Expected application type: {app_type}, but found: {element.text}"
            self.logger.info(f"Applications filtered by type '{app_type}' verified successfully")
        except Exception as e:
            self.logger.error(f"Failed to verify applications filtered by type '{app_type}': {str(e)}")
            raise

    def view_latest_result(self):
        self.logger.info("Attempting to view the latest result")
        try:
            ActionUtils.scroll_to_element_and_click(self.driver, By.XPATH, self.latest_result, "Latest Result")
            self.logger.info("Latest result viewed successfully")
        except ElementClickInterceptedException:
            self.logger.info("Element click intercepted, trying with JavaScript click")
            ActionUtils.click_element_js(self.driver, By.XPATH, self.latest_result, "Latest Result")
        except Exception as e:
            self.logger.error(f"Failed to view the latest result: {str(e)}")
            raise

    def apply_severity_filter(self, severity):
        self.logger.info(f"Attempting to apply severity filter: {severity}")
        try:
            severity_locator = (By.XPATH, self.severity_filter.format(severity))
            try:
                ActionUtils.click(self.driver, severity_locator[0], severity_locator[1], "Severity Filter")
            except ElementClickInterceptedException:
                ActionUtils.click_element_js(self.driver, severity_locator[0], severity_locator[1], "Severity Filter")
            self.logger.info(f"Severity filter '{severity}' applied successfully")
        except Exception as e:
            self.logger.error(f"Failed to apply severity filter '{severity}': {str(e)}")
            raise

    def apply_scan_type_filter(self, scan_type):
        self.logger.info(f"Attempting to apply scan type filter: {scan_type}")
        try:
            scan_type_locator = (By.XPATH, self.scan_type_filter.format(scan_type))
            ActionUtils.click(self.driver, *scan_type_locator, "Scan Type Filter")
            self.logger.info(f"Scan type filter '{scan_type}' applied successfully")
        except Exception as e:
            self.logger.error(f"Failed to apply scan type filter '{scan_type}': {str(e)}")
            raise

    def verify_filtered_results(self, severity, scan_type):
        self.logger.info(f"Attempting to verify filtered results for severity '{severity}' and scan type '{scan_type}'")
        try:
            severity_locator = (By.XPATH, self.issue_severity.format(severity))
            scan_type_locator = (By.XPATH, self.issue_scan_type.format(scan_type))

            severity_elements = ActionUtils.get_elements(self.driver, *severity_locator, timeout=20)
            scan_type_elements = ActionUtils.get_elements(self.driver, *scan_type_locator, timeout=20)

            assert severity_elements, f"No elements found with severity: {severity}"
            assert scan_type_elements, f"No elements found with scan type: {scan_type}"

            for element in severity_elements:
                self.logger.info(f"Found severity element with text: {element.text}")
                assert severity in element.text.lower(), f"Expected severity: {severity}, but found: {element.text}"

            for element in scan_type_elements:
                self.logger.info(f"Found scan type element with text: {element.text}")
                assert scan_type in element.text.lower(), f"Expected scan type: {scan_type}, but found: {element.text}"

            self.logger.info(f"Filtered results for severity '{severity}' and scan type '{scan_type}' verified successfully")
        except Exception as e:
            self.logger.error(f"Failed to verify filtered results for severity '{severity}' and scan type '{scan_type}': {str(e)}")
            raise
