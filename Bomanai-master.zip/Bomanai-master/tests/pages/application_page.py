import time

from selenium.webdriver.common.by import By
from tests.pages.base_page import BasePage
from utils.action_utils import ActionUtils
from utils.logger import logger

class ApplicationPage(BasePage):
    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver
        self.logger = logger

    # Locators as strings
    application_icon = "//a[@href='/apps']"
    application_name = "//a[text()='{}']"
    application_three_dots = "(//*[name()='svg'][@role='img'])[19]"
    application_three_dots1 = "(//*[name()='svg'][@role='img'])[20]"
    view_all_scans1 = "//div[@class='dropdown-menu dropdown-menu-right show']//a[@class='dropdown-item'][normalize-space()='View All Scan']"
    no_scan_found_message = "//div[contains(@class, 'toast-error') and contains(text(), 'No scans results found for this request')]"
    item_count = "//div[@class='items-count']"
    expand_scan = "(//div[@class='div-over-flow'])[1]"
    last_scan_date = "(//div[@class='card-text d-inline text-dark fs-0'])[2]"
    last_date_scan = "//div[normalize-space()='Initiated on Mon, 17 Jun 2024 04:47:10 UTC']"
    expand_vulnerability1 = "//a[normalize-space()='SCAN-170620240bd002']"
    no_of_scans = "//li[.//span[text()='No of Scans']]/span[@class='badge badge-sm badge-outline-dark']"
    vulnerability_status = "(//input[@id='0'])[1]"
    status = "(//div[@class='vuln-box status-pending'][normalize-space()='Pending'])[2]"
    creation_date = "//div[contains(text(),'Created on')]"
    application_type = "//li[.//span[text()='Type']]/span[@class='badge badge-sm badge-outline-dark']"
    technology = "//li[.//span[text()='Technology']]/span[@class='badge badge-sm badge-outline-dark']"
    get_ci_cd_config1 = "//div[@class='dropdown-menu dropdown-menu-right show']//a[normalize-space()='Get CI/CD Config']"
    select_ci_cd_dropdown = "//select[@id='cicd_service']"
    download_file_button = "//input[@value='Download File']"
    create_boman_config = "//div[@class='dropdown-menu dropdown-menu-right show']//a[@class='dropdown-item create-config-link'][normalize-space()='Create Boman Config']"
    sast_checkbox = "//input[@id='fast']"
    sca_checkbox = "//input[@id='sca']"
    secret_scanning_checkbox = "//input[@id='secret_scanning']"
    dast_checkbox = "//input[@id='dast']"
    dast_url_input = "//input[@id='pipeline_url']"
    generate_and_download_button = "//input[@value='Generate & Download']"
    error_message = "//div[contains(@class, 'toast-error') and contains(text(), 'No scans results found for this request')]"

    def navigate_to_applications_page(self):
        self.logger.info("Navigating to applications page")
        try:
            ActionUtils.click(self.driver, By.XPATH, self.application_icon, "Applications Icon")
            self.logger.info("Navigated to applications page successfully")
        except Exception as e:
            self.logger.error(f"Failed to navigate to applications page: {str(e)}")
            raise

    def verify_application_present(self, app_name):
        self.logger.info(f"Verifying application {app_name} is present")
        try:
            app_present = ActionUtils.is_element_displayed(self.driver, By.XPATH, self.application_name.format(app_name), f"Application {app_name}")
            assert app_present, f"Application {app_name} should be present on the Applications page"
            self.logger.info(f"Application {app_name} is present")
        except Exception as e:
            self.logger.error(f"Failed to verify application {app_name}: {str(e)}")
            raise

    def view_all_scans(self, app_name):
        self.logger.info(f"Viewing all scans for application {app_name}")
        try:
            ActionUtils.click(self.driver, By.XPATH, self.application_three_dots, f"Application {app_name} three dots")
            ActionUtils.click(self.driver, By.XPATH, self.view_all_scans1, "View All Scans")
            self.logger.info(f"Viewed all scans for application {app_name} successfully")
        except Exception as e:
            self.logger.error(f"Failed to view all scans for application {app_name}: {str(e)}")
            raise

    def view_all_scans_result(self, app_name):
        self.logger.info(f"Viewing all scans result for application {app_name}")
        try:
            ActionUtils.click(self.driver, By.XPATH, self.application_three_dots1, f"Application {app_name} three dots")
            ActionUtils.click(self.driver, By.XPATH, self.view_all_scans1, "View All Scans")
            self.logger.info(f"Viewed all scans result for application {app_name} successfully")
        except Exception as e:
            self.logger.error(f"Failed to view all scans result for application {app_name}: {str(e)}")
            raise

    def verify_no_scan_found_message(self):
        self.logger.info("Verifying no scan found toastr error message")
        try:
            ActionUtils.verify_toast_message(self.driver, "No scans results found for this request")
            self.logger.info("No scan found toastr error message verified successfully")
        except Exception as e:
            self.logger.error(f"Failed to verify no scan found toastr error message: {str(e)}")
            raise

    def verify_scan_count(self, expected_count):
        self.logger.info(f"Verifying scan count: {expected_count}")
        try:
            scan_count = int(ActionUtils.get_element_text(self.driver, By.XPATH, self.item_count, "Item Count").strip())
            assert scan_count == expected_count, f"Expected scan count: {expected_count}, but found: {scan_count}"
            self.logger.info(f"Verified scan count successfully: {expected_count}")
        except Exception as e:
            self.logger.error(f"Failed to verify scan count: {str(e)}")
            raise

    def verify_last_scan_date(self, expected_date):
        self.logger.info(f"Verifying last scan date: {expected_date}")
        try:
            last_scan_date = ActionUtils.get_element_text(self.driver, By.XPATH, self.last_date_scan, "Last Date Scan").strip()
            assert last_scan_date == expected_date, f"Expected last scan date: {expected_date}, but found: {last_scan_date}"
            self.logger.info(f"Verified last scan date successfully: {expected_date}")
        except Exception as e:
            self.logger.error(f"Failed to verify last scan date: {str(e)}")
            raise

    def expand_vulnerability(self):
        self.logger.info("Expanding vulnerability")
        try:
            ActionUtils.click(self.driver, By.XPATH, self.expand_vulnerability1, "Expand Vulnerability")
            self.logger.info("Expanded vulnerability successfully")
        except Exception as e:
            self.logger.error(f"Failed to expand vulnerability: {str(e)}")
            raise

    def verify_vulnerability_status(self, expected_status):
        self.logger.info(f"Verifying vulnerability status: {expected_status}")
        try:
            ActionUtils.click_element_js(self.driver, By.XPATH, self.vulnerability_status, "Vulnerability Status")
            ActionUtils.click(self.driver, By.XPATH, self.expand_scan, "Expand Scan")
            status = ActionUtils.get_element_text(self.driver, By.XPATH, self.status, "Status").strip()
            assert status == expected_status, f"Expected vulnerability status: {expected_status}, but found: {status}"
            self.logger.info(f"Verified vulnerability status successfully: {expected_status}")
        except Exception as e:
            self.logger.error(f"Failed to verify vulnerability status: {str(e)}")
            raise

    def verify_creation_date(self, expected_date):
        self.logger.info(f"Verifying creation date: {expected_date}")
        try:
            creation_date = ActionUtils.get_element_text(self.driver, By.XPATH, self.creation_date, "Creation Date").strip()
            assert creation_date == expected_date, f"Expected creation date: {expected_date}, but found: {creation_date}"
            self.logger.info(f"Verified creation date successfully: {expected_date}")
        except Exception as e:
            self.logger.error(f"Failed to verify creation date: {str(e)}")
            raise

    def verify_application_type(self, expected_type):
        self.logger.info(f"Verifying application type: {expected_type}")
        try:
            app_type = ActionUtils.get_element_text(self.driver, By.XPATH, self.application_type, "Application Type").strip().replace('\u00a0', ' ')
            assert app_type.lower() == expected_type.lower(), f"Expected application type: {expected_type}, but found: {app_type}"
            self.logger.info(f"Verified application type successfully: {expected_type}")
        except Exception as e:
            self.logger.error(f"Failed to verify application type: {str(e)}")
            raise

    def verify_technology(self, expected_technology):
        self.logger.info(f"Verifying technology: {expected_technology}")
        try:
            technology = ActionUtils.get_element_text(self.driver, By.XPATH, self.technology, "Technology").strip().replace('\u00a0', ' ')
            assert technology.lower() == expected_technology.lower(), f"Expected technology: {expected_technology}, but found: {technology}"
            self.logger.info(f"Verified technology successfully: {expected_technology}")
        except Exception as e:
            self.logger.error(f"Failed to verify technology: {str(e)}")
            raise

    def verify_no_of_scans(self, expected_count):
        self.logger.info(f"Verifying number of scans: {expected_count}")
        try:
            scan_count = int(ActionUtils.get_element_text(self.driver, By.XPATH, self.no_of_scans, "Number of Scans").strip())
            assert scan_count == expected_count, f"Expected scan count: {expected_count}, but found: {scan_count}"
            self.logger.info(f"Verified number of scans successfully: {expected_count}")
        except Exception as e:
            self.logger.error(f"Failed to verify number of scans: {str(e)}")
            raise

    def verify_last_scan(self, expected_last_scan):
        self.logger.info(f"Verifying last scan: {expected_last_scan}")
        try:
            last_scan = ActionUtils.get_element_text(self.driver, By.XPATH, self.last_scan_date, "Last Scan Date").strip().replace("Last scan: ", "")
            assert last_scan == expected_last_scan, f"Expected last scan: {expected_last_scan}, but found: {last_scan}"
            self.logger.info(f"Verified last scan successfully: {expected_last_scan}")
        except Exception as e:
            self.logger.error(f"Failed to verify last scan: {str(e)}")
            raise

    def get_ci_cd_config(self, app_name, ci_cd_tool):
        self.logger.info(f"Getting CI/CD config for {app_name} using {ci_cd_tool}")
        try:
            ActionUtils.click(self.driver, By.XPATH, self.application_three_dots1, f"Application {app_name} three dots")
            time.sleep(3)
            ActionUtils.click(self.driver, By.XPATH, self.get_ci_cd_config1, "Get CI/CD Config")
            time.sleep(3)
            ActionUtils.select_from_dropdown(self.driver, By.XPATH, self.select_ci_cd_dropdown, ci_cd_tool, "CI/CD Dropdown")
            time.sleep(3)
            ActionUtils.click(self.driver, By.XPATH, self.download_file_button, "Download File Button")
            self.logger.info(f"Got CI/CD config for {app_name} using {ci_cd_tool} successfully")
        except Exception as e:
            self.logger.error(f"Failed to get CI/CD config for {app_name} using {ci_cd_tool}: {str(e)}")
            raise

    def open_application_menu(self, app_name):
        ActionUtils.click(self.driver, By.XPATH, self.application_three_dots, f"Application {app_name} three dots")

    def select_create_boman_config(self):
        ActionUtils.click(self.driver, By.XPATH, self.create_boman_config, "Create Boman Config")

    def uncheck_sast_checkbox(self):
        ActionUtils.uncheck_checkbox(self.driver, By.XPATH, self.sast_checkbox, "SAST Checkbox")

    def check_sca_checkbox(self):
        ActionUtils.check_checkbox(self.driver, By.XPATH, self.sca_checkbox, "SCA Checkbox")

    def check_secret_scanning_checkbox(self):
        ActionUtils.check_checkbox(self.driver, By.XPATH, self.secret_scanning_checkbox, "Secret Scanning Checkbox")

    def check_dast_checkbox(self):
        ActionUtils.check_checkbox(self.driver, By.XPATH, self.dast_checkbox, "DAST Checkbox")

    def enter_dast_url(self, url):
        ActionUtils.enter_text(self.driver, By.XPATH, self.dast_url_input, url, "DAST URL")

    def click_generate_and_download(self):
        ActionUtils.click(self.driver, By.XPATH, self.generate_and_download_button, "Generate and Download Button")

    def verify_download_file_name(self, expected_file_name):
        downloaded_file_name = ActionUtils.get_downloaded_file_name(expected_file_name)
        assert downloaded_file_name == expected_file_name, f"Expected file name: {expected_file_name}, but found: {downloaded_file_name}"

    def verify_error_message(self, expected_message):
        error_message = ActionUtils.get_element_text(self.driver, By.XPATH, self.error_message, "Error Message")
        assert error_message == expected_message, f"Expected error message: {expected_message}, but found: {error_message}"
