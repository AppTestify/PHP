from selenium.webdriver.common.by import By
from tests.pages.base_page import BasePage
from utils.action_utils import ActionUtils
from utils.logger import logger

class CLIPage(BasePage):
    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver
        self.logger = logger

    # Locators as strings
    cli_menu = "//a[@href='/cli']"
    trigger_scan_button = "//button[@id='trigger-scan']"
    scan_result = "//div[@id='scan-result']"
    download_yaml_button = "//button[@id='download-yaml']"
    upload_yaml_input = "//input[@id='upload-yaml']"
    upload_yaml_button = "//button[@id='upload-yaml-btn']"
    error_message = "//div[@class='error-message']"
    scan_status = "//div[@id='scan-status']"

    def open_cli_page(self):
        self.logger.info("Opening CLI page")
        ActionUtils.click(self.driver, By.XPATH, self.cli_menu, "CLI Menu")

    def trigger_scan(self):
        self.logger.info("Triggering scan")
        ActionUtils.click(self.driver, By.XPATH, self.trigger_scan_button, "Trigger Scan Button")

    def get_scan_result(self):
        self.logger.info("Retrieving scan result")
        result = ActionUtils.get_element_text(self.driver, By.XPATH, self.scan_result, "Scan Result")
        self.logger.info(f"Scan result: {result}")
        return result

    def download_boman_yaml(self):
        self.logger.info("Downloading boman.yaml file")
        ActionUtils.click(self.driver, By.XPATH, self.download_yaml_button, "Download boman.yaml Button")

    def upload_boman_yaml(self, file_path):
        self.logger.info(f"Uploading boman.yaml file from {file_path}")
        ActionUtils.upload_file(self.driver, By.XPATH, self.upload_yaml_input, file_path, "Upload boman.yaml Input")
        ActionUtils.click(self.driver, By.XPATH, self.upload_yaml_button, "Upload boman.yaml Button")

    def get_error_message(self):
        self.logger.info("Retrieving error message")
        error_message = ActionUtils.get_element_text(self.driver, By.XPATH, self.error_message, "Error Message")
        self.logger.info(f"Error message: {error_message}")
        return error_message

    def check_scan_status(self):
        self.logger.info("Checking scan status")
        status = ActionUtils.get_element_text(self.driver, By.XPATH, self.scan_status, "Scan Status")
        self.logger.info(f"Scan status: {status}")
        return status
