from selenium.webdriver.common.by import By
from tests.pages.base_page import BasePage
from utils.action_utils import ActionUtils
from utils.logger import logger


class DashboardPage(BasePage):
    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver
        self.logger = logger

    # Locators as strings
    dashboard_menu = "//a[@href='/dashboard']"
    total_apps = "//span[@id='total-apps']"
    total_successful_scans = "//span[@id='total-successful-scans']"
    vulnerabilities_menu = "//a[@href='/vulnerabilities']"
    export_excel = "//button[@id='export-excel']"
    export_report = "//button[@id='export-report']"
    add_to_jira = "//button[@id='add-to-jira']"
    edit_in_jira = "//button[@id='edit-in-jira']"
    quick_view = "//button[@id='quick-view']"
    back_to_findings = "//a[@id='back-to-findings']"
    details_overlay = "//div[@id='details-overlay']"
    solution_page = "//a[@href='/solution']"

    def open_dashboard_page(self):
        self.logger.info("Opening dashboard page")
        ActionUtils.click(self.driver, By.XPATH, self.dashboard_menu, "Dashboard Menu")

    def view_total_apps(self):
        self.logger.info("Viewing total number of apps")
        total_apps = ActionUtils.get_element_text(self.driver, By.XPATH, self.total_apps, "Total Apps")
        self.logger.info(f"Total number of apps: {total_apps}")
        return total_apps

    def view_total_successful_scans(self):
        self.logger.info("Viewing total number of successful scans")
        total_scans = ActionUtils.get_element_text(self.driver, By.XPATH, self.total_successful_scans, "Total Successful Scans")
        self.logger.info(f"Total number of successful scans: {total_scans}")
        return total_scans

    def open_vulnerabilities_page(self):
        self.logger.info("Opening vulnerabilities page")
        ActionUtils.click(self.driver, By.XPATH, self.vulnerabilities_menu, "Vulnerabilities Menu")

    def export_vulnerabilities_excel(self):
        self.logger.info("Exporting vulnerabilities to Excel")
        ActionUtils.click(self.driver, By.XPATH, self.export_excel, "Export to Excel")

    def export_vulnerabilities_report(self):
        self.logger.info("Exporting vulnerabilities to Report")
        ActionUtils.click(self.driver, By.XPATH, self.export_report, "Export to Report")

    def add_vulnerability_to_jira(self):
        self.logger.info("Adding vulnerability to Jira")
        ActionUtils.click(self.driver, By.XPATH, self.add_to_jira, "Add to Jira")

    def edit_vulnerability_in_jira(self):
        self.logger.info("Editing vulnerability in Jira")
        ActionUtils.click(self.driver, By.XPATH, self.edit_in_jira, "Edit in Jira")

    def quick_view_vulnerability(self):
        self.logger.info("Quick viewing vulnerability")
        ActionUtils.click(self.driver, By.XPATH, self.quick_view, "Quick View")

    def navigate_back_to_findings(self):
        self.logger.info("Navigating back to Findings page")
        ActionUtils.click(self.driver, By.XPATH, self.back_to_findings, "Back to Findings")

    def view_details_overlay(self):
        self.logger.info("Viewing details on overlay")
        ActionUtils.click(self.driver, By.XPATH, self.details_overlay, "Details Overlay")

    def verify_solution_page(self):
        self.logger.info("Verifying solution for application")
        ActionUtils.click(self.driver, By.XPATH, self.solution_page, "Solution Page")
