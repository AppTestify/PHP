from selenium.webdriver import ActionChains
from selenium.webdriver.common.by import By

from utils.action_utils import ActionUtils
from .base_page import BasePage
from utils.logger import logger


class LoginPage(BasePage):
    EMAIL_INPUT = (By.NAME, 'user[email]')
    PASSWORD_INPUT = (By.NAME, 'user[password]')
    LOGIN_BUTTON = (By.XPATH, "//input[@name='commit']")
    FORGOT_PASSWORD_LINK = "Forgot Password?"
    SHOW_PASSWORD_CHECKBOX = (By.XPATH, "//input[@id='show_password']")
    ERROR_MESSAGE = (By.XPATH, "//div[@id='error_explanation']")

    def enter_email(self, email):
        logger.info(f"Entering email: {email}")
        self.enter_text(self.EMAIL_INPUT, email)

    def enter_password(self, password):
        logger.info(f"Entering password: {password}")
        self.enter_text(self.PASSWORD_INPUT, password)

    def click_login(self):
        logger.info("Clicking login button")
        self.click(self.LOGIN_BUTTON)

    def click_forgot_password(self):
        logger.info("Clicking forgot password link")
        forgot_password_link = self.find_element((By.LINK_TEXT, self.FORGOT_PASSWORD_LINK))
        forgot_password_link.click()

    def check_show_password(self):
        logger.info("Checking show password checkbox")
        self.click(self.SHOW_PASSWORD_CHECKBOX)

    def get_error_message(self):
        logger.info("Getting error message text")
        return self.find_element(self.ERROR_MESSAGE).text

    def get_email_format_error_message(self):
        logger.info("Retrieving generic error message")
        email_input = self.find_element(self.EMAIL_INPUT)
        error_message = self.driver.execute_script("return arguments[0].validationMessage;", email_input)
        return error_message

    def hover_over_forgot_password(self):
        logger.info("Hovering over 'Forgot Password?' link")
        try:
            forgot_password_link = ActionUtils.wait_for_element(self.driver, By.LINK_TEXT, self.FORGOT_PASSWORD_LINK, "ForGot Password")
            ActionChains(self.driver).move_to_element(forgot_password_link).perform()
            color = forgot_password_link.value_of_css_property('color')
            logger.info(f"'Forgot Password?' link color on hover: {color}")
            return color
        except Exception as e:
            logger.error(f"Error hovering over 'Forgot Password?' link: {str(e)}")
            raise

    def login(self, email, password):
        self.enter_email(email)
        self.enter_password(password)
        self.click_login()
