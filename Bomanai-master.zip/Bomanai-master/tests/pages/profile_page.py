from selenium.webdriver.common.by import By
from tests.pages.base_page import BasePage
from utils.action_utils import ActionUtils
from utils.logger import logger
import time

class ProfilePage(BasePage):
    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver
        self.logger = logger

    # Locators as strings
    profile_menu = "//a[@id='navbarDropdown']"
    profile_option = "//a[@href='/profile']"
    edit_profile_button = "//button[contains(@class, 'edit-profile')]"
    organisation_name_input = "//input[@name='organisation_name']"
    address_input = "//input[@name='address']"
    phone_no_input = "//input[@name='phone_no']"
    update_button = "//button[contains(@class, 'update-profile')]"
    change_password_button = "//button[contains(@class, 'change-password')]"
    current_password_input = "//input[@name='current_password']"
    new_password_input = "//input[@name='new_password']"
    confirm_password_input = "//input[@name='confirm_password']"
    change_password_submit_button = "//button[contains(@class, 'change-password-submit')]"
    add_user_button = "//button[contains(@class, 'add-user')]"
    user_name_input = "//input[@name='user_name']"
    user_email_input = "//input[@name='user_email']"
    co_admin_checkbox = "//input[@name='co_admin']"
    add_user_submit_button = "//button[contains(@class, 'add-user-submit')]"

    def open_profile_page(self):
        self.logger.info("Opening profile page")
        time.sleep(7)
        ActionUtils.click(self.driver, By.XPATH, self.profile_menu, "Profile Menu")
        ActionUtils.click(self.driver, By.XPATH, self.profile_option, "Profile Option")

    def update_profile_info(self, organisation_name, address, phone_no):
        self.logger.info("Updating profile information")
        ActionUtils.click(self.driver, By.XPATH, self.edit_profile_button, "Edit Profile Button")
        ActionUtils.enter_text(self.driver, By.XPATH, self.organisation_name_input, organisation_name, "Organisation Name Input")
        ActionUtils.enter_text(self.driver, By.XPATH, self.address_input, address, "Address Input")
        ActionUtils.enter_text(self.driver, By.XPATH, self.phone_no_input, phone_no, "Phone Number Input")
        ActionUtils.click(self.driver, By.XPATH, self.update_button, "Update Button")

    def change_password(self, current_password, new_password):
        self.logger.info("Changing password")
        ActionUtils.click(self.driver, By.XPATH, self.change_password_button, "Change Password Button")
        ActionUtils.enter_text(self.driver, By.XPATH, self.current_password_input, current_password, "Current Password Input")
        ActionUtils.enter_text(self.driver, By.XPATH, self.new_password_input, new_password, "New Password Input")
        ActionUtils.enter_text(self.driver, By.XPATH, self.confirm_password_input, new_password, "Confirm Password Input")
        ActionUtils.click(self.driver, By.XPATH, self.change_password_submit_button, "Change Password Submit Button")

    def add_user(self, name, email, co_admin=False):
        self.logger.info("Adding a new user")
        ActionUtils.click(self.driver, By.XPATH, self.add_user_button, "Add User Button")
        ActionUtils.enter_text(self.driver, By.XPATH, self.user_name_input, name, "User Name Input")
        ActionUtils.enter_text(self.driver, By.XPATH, self.user_email_input, email, "User Email Input")
        if co_admin:
            ActionUtils.click(self.driver, By.XPATH, self.co_admin_checkbox, "Co-Admin Checkbox")
        ActionUtils.click(self.driver, By.XPATH, self.add_user_submit_button, "Add User Submit Button")

    def delete_user(self, email):
        self.logger.info(f"Deleting user with email: {email}")
        delete_button = "(//div[@class='delete-icon'])[4]"
        try:
            ActionUtils.scroll_to_element_and_click(self.driver, By.XPATH, delete_button, "Delete Button")
            ActionUtils.confirm_alert(self.driver)
        except Exception as e:
            self.logger.error(f"Failed to delete user: {str(e)}")
            raise
