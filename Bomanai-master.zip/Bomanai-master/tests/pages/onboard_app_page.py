from selenium.webdriver.common.by import By
from tests.pages.base_page import BasePage
from utils.action_utils import ActionUtils
from utils.logger import logger

class OnboardAppPage(BasePage):
    onboard_app = "//a[normalize-space()='+ Onboard App']"
    next_button = "//div[@id='#']//button[@type='button'][normalize-space()='Next']"
    next_button_tech = "//div[@id='wizard_choose_tech']//button[@type='button'][normalize-space()='Next']"
    next_button_selectApp = "//div[@id='wizard_choose_app_details']//button[@type='button'][normalize-space()='Next']"
    app_type = "//label[@for='apptype1']"
    language = "//label[@for='tech1']"
    toggle_button_knobs1 = "//input[@id='internet_facing']"
    toggle_button_knobs2 = "//input[@id='database']"
    toggle_button_knobs3 = "//input[@id='login']"
    rate_input = "//input[@id='business_criticality']"
    rate_input_data_sensitivity = "//input[@id='data_sensitivity']"
    num_input_developers = "//input[@id='developers']"
    num_input_security_experts = "//input[@id='security_experts']"
    build_server_dropdown = "//select[@id='build_server']"
    app_name = "//input[@id='application_name']"
    terms_checkbox = "//input[@id='terms_and_conditions']"
    finish_button = "//button[normalize-space()='Finish']"
    success_message = "//h3[normalize-space()='Your App has been Successfully Added']"
    download_boman_yaml = "//a[normalize-space()='Download Boman .yml']"
    download_ci_cd_config = "//a[normalize-space()='Download CI/CD config file']"
    error_message = "//div[@class='msg']"
    terms_error_message = "//div[text()='Please Agree to our terms and conditions']"
    close_app = "//button[@aria-label='Close']"
    max_app_limit_warning = "//h4[contains(text(),'You have reached MAX APP limit, Please contact bom')]"

    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver
        self.logger = logger

    def click_onboard_app_button(self):
        ActionUtils.click(self.driver, By.XPATH, self.onboard_app, "Onboard App Button")

    def select_app_type(self, app_type):
        ActionUtils.click(self.driver, By.XPATH, self.app_type.format(app_type), f"App Type '{app_type}'")
        ActionUtils.click(self.driver, By.XPATH, self.next_button, "Next Button")

    def select_language(self, language):
        ActionUtils.click(self.driver, By.XPATH, self.language.format(language), f"Language '{language}'")
        ActionUtils.click(self.driver, By.XPATH, self.next_button_tech, "Next Button Tech")

    def configure_app_slider(self, rate4=5, rate5=5, num6=50, num7=50):
        ActionUtils.enter_text(self.driver, By.XPATH, self.rate_input, str(rate4), "Business Criticality Slider")
        ActionUtils.enter_text(self.driver, By.XPATH, self.rate_input_data_sensitivity, str(rate5), "Data Sensitivity Slider")
        ActionUtils.enter_text(self.driver, By.XPATH, self.num_input_developers, str(num6), "Number of Developers Slider")
        ActionUtils.enter_text(self.driver, By.XPATH, self.num_input_security_experts, str(num7), "Number of Security Experts Slider")
        ActionUtils.click(self.driver, By.XPATH, self.next_button_selectApp, "Next Button SelectApp")

    def select_ci_cd(self, ci_cd_tool):
        ActionUtils.select_dropdown(self.driver, By.XPATH, self.build_server_dropdown, ci_cd_tool, "CI/CD Tool Dropdown")

    def enter_app_name(self, name):
        ActionUtils.enter_text(self.driver, By.XPATH, self.app_name, name, "App Name Input")

    def agree_terms_and_finish(self):
        ActionUtils.click(self.driver, By.XPATH, self.terms_checkbox, "Terms Checkbox")
        ActionUtils.click(self.driver, By.XPATH, self.finish_button, "Finish Button")

    def verify_success_message(self):
        try:
            success_message = ActionUtils.get_element_text(self.driver, By.XPATH, self.success_message,
                                                           "Success Message")
            result = "Your App has been Successfully Added" in success_message
            return result
        except Exception as e:
            logger.error(f"Failed to verify success message: {str(e)}")
            raise

    def verify_download_buttons(self):
        try:
            download_boman_yaml = ActionUtils.is_element_displayed(self.driver, By.XPATH, self.download_boman_yaml, "Download Boman YAML Button")
            download_ci_cd_config = ActionUtils.is_element_displayed(self.driver, By.XPATH, self.download_ci_cd_config, "Download CI/CD Config Button")
            result = download_boman_yaml and download_ci_cd_config
            return result
        except Exception as e:
            raise

    def click_next(self):
        ActionUtils.click(self.driver, By.XPATH, self.next_button, "Next Button")

    def click_next_tech(self):
        ActionUtils.click(self.driver, By.XPATH, self.next_button_tech, "Next Tech Button")

    def click_next_selectapp(self):
        ActionUtils.click(self.driver, By.XPATH, self.next_button_selectApp, "Next Select App Button")

    def click_finish_button(self):
        ActionUtils.click(self.driver, By.XPATH, self.finish_button, "Finish Button")

    def get_error_message(self):
        return ActionUtils.verify_text(self.driver, By.XPATH, self.error_message, "", "Error Message")

    def verify_step1_error_message(self):
        expected_message = "Please select any option from the below"
        actual_message = self.get_error_message()
        assert expected_message in actual_message, f"Expected error message: {expected_message}, but found: {actual_message}"

    def verify_step2_error_message(self):
        expected_message = "Please select any option from the below"
        actual_message = self.get_error_message()
        assert expected_message in actual_message, f"Expected error message: {expected_message}, but found: {actual_message}"

    def verify_step3_error_message(self):
        expected_message = "Please choose the Business Criticality"
        actual_message = self.get_error_message()
        assert expected_message in actual_message, f"Expected error message: {expected_message}, but found: {actual_message}"

    def verify_done_step_error_messages(self):
        terms_message = "Please Agree to our terms and conditions"
        actual_terms_message = ActionUtils.verify_text(self.driver, By.XPATH, self.terms_error_message, terms_message, "Terms Error Message")
        assert terms_message in actual_terms_message, f"Expected terms error message: {terms_message}, but found: {actual_terms_message}"

    def is_max_app_limit_reached(self):
        try:
            warning_message = ActionUtils.get_element_text(self.driver, By.XPATH, self.max_app_limit_warning,
                                                           "Max App Limit Warning")
            if "You have reached MAX APP limit, Please contact boman admin." in warning_message:
                logger.warning("Max app limit reached: skipping test")
                return True
            return False
        except Exception:
            return False
