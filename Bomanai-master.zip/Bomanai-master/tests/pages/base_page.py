from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from utils.logger import logger


class BasePage:
    def __init__(self, driver):
        self.driver = driver

    def find_element(self, locator, timeout=10):
        try:
            element = WebDriverWait(self.driver, timeout).until(EC.presence_of_element_located(locator))
            return element
        except Exception as e:
            logger.error(f"Error finding element {locator}: {str(e)}")
            self.take_screenshot("error_finding_element")
            raise

    def click(self, locator, timeout=10):
        try:
            element = self.find_element(locator, timeout)
            element.click()
        except Exception as e:
            logger.error(f"Error clicking element {locator}: {str(e)}")
            self.take_screenshot("error_clicking_element")
            raise

    def enter_text(self, locator, text, timeout=10):
        try:
            element = self.find_element(locator, timeout)
            element.send_keys(text)
        except Exception as e:
            logger.error(f"Error entering text into element {locator}: {str(e)}")
            self.take_screenshot("error_entering_text")
            raise

    def take_screenshot(self, name):
        screenshot_name = f"screenshots/{name}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
        self.driver.save_screenshot(screenshot_name)
        logger.info(f"Screenshot saved as {screenshot_name}")
