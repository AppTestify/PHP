from selenium.webdriver.common.by import By
from tests.pages.base_page import BasePage
from utils.action_utils import ActionUtils
from utils.logger import logger

class VulnerabilitiesPage(BasePage):
    def __init__(self, driver):
        super().__init__(driver)
        self.driver = driver
        self.logger = logger

    # Locators as strings
    three_dots = "(//*[name()='svg'][@role='img'])[22]"
    mark_all_as_fixed1 = "//div[@id='dropdown-0']//button[@type='submit'][normalize-space()='Mark All as Fixed']"
    mark_all_as_accepted_risk1 = "(//button[@type='submit'][normalize-space()='Mark All as Accepted Risk'])[1]"
    mark_all_as_in_progress1 = "(//button[@type='submit'][normalize-space()='Mark All as In Progress'])[1]"
    mark_all_as_pending1 = "(//button[@type='submit'][normalize-space()='Mark All as Pending'])[1]"
    mark_all_as_pending_fix1 = "(//button[@type='submit'][normalize-space()='Mark All as Pending Fix'])[1]"
    mark_all_as_false_positive1 = "(//button[@type='submit'][normalize-space()='Mark All as False Positive'])[1]"
    status = "(//div[@class='div-over-flow'])[1]"
    status1 = "(//div[@class='project-info'])[4]"
    vul_status = "div[id='flush-collapse-0'] div[class='vuln-box status-closed']"
    vul_status1 = "(//div[contains(text(),'Accepted Risk')])[2]"
    pending = "input[id='0']"

    def mark_all_as_fixed(self):
        self.logger.info("Attempting to mark all vulnerabilities as fixed")
        try:
            ActionUtils.click(self.driver, By.XPATH, self.three_dots, "Three Dots")
            ActionUtils.click(self.driver, By.XPATH, self.mark_all_as_fixed1, "Mark All as Fixed")
            self.logger.info("All vulnerabilities marked as fixed (alert dismissed)")
        except Exception as e:
            self.logger.error(f"Failed to mark all vulnerabilities as fixed: {str(e)}")
            raise

    def mark_all_as_accepted_risk(self):
        self.logger.info("Attempting to mark all vulnerabilities as accepted risk")
        try:
            ActionUtils.click(self.driver, By.XPATH, self.three_dots, "Three Dots")
            ActionUtils.click(self.driver, By.XPATH, self.mark_all_as_accepted_risk1, "Mark All as Accepted Risk")
            self.logger.info("All vulnerabilities marked as accepted risk (alert accepted)")
        except Exception as e:
            self.logger.error(f"Failed to mark all vulnerabilities as accepted risk: {str(e)}")
            raise

    def mark_all_as_in_progress(self):
        self.logger.info("Attempting to mark all vulnerabilities as in progress")
        try:
            ActionUtils.click(self.driver, By.XPATH, self.three_dots, "Three Dots")
            ActionUtils.click(self.driver, By.XPATH, self.mark_all_as_in_progress1, "Mark All as In Progress")
            ActionUtils.confirm_alert(self.driver)
            self.logger.info("All vulnerabilities marked as in progress")
        except Exception as e:
            self.logger.error(f"Failed to mark all vulnerabilities as in progress: {str(e)}")
            raise

    def mark_all_as_pending(self):
        self.logger.info("Attempting to mark all vulnerabilities as pending")
        try:
            ActionUtils.click(self.driver, By.XPATH, self.three_dots, "Three Dots")
            ActionUtils.click(self.driver, By.XPATH, self.mark_all_as_pending1, "Mark All as Pending")
            ActionUtils.confirm_alert(self.driver)
            self.logger.info("All vulnerabilities marked as pending")
        except Exception as e:
            self.logger.error(f"Failed to mark all vulnerabilities as pending: {str(e)}")
            raise

    def mark_all_as_pending_fix(self):
        self.logger.info("Attempting to mark all vulnerabilities as pending fix")
        try:
            ActionUtils.click(self.driver, By.XPATH, self.three_dots, "Three Dots")
            ActionUtils.click(self.driver, By.XPATH, self.mark_all_as_pending_fix1, "Mark All as Pending Fix")
            ActionUtils.confirm_alert(self.driver)
            self.logger.info("All vulnerabilities marked as pending fix")
        except Exception as e:
            self.logger.error(f"Failed to mark all vulnerabilities as pending fix: {str(e)}")
            raise

    def mark_all_as_false_positive_sca_secret(self):
        self.logger.info("Attempting to mark all vulnerabilities as false positive (SCA/Secret Scan)")
        try:
            ActionUtils.click(self.driver, By.XPATH, self.three_dots, "Three Dots")
            ActionUtils.click(self.driver, By.XPATH, self.mark_all_as_false_positive1, "Mark All as False Positive")
            self.logger.info("Attempt to mark vulnerabilities as false positive was not allowed")
        except Exception as e:
            self.logger.error(f"Failed to mark all vulnerabilities as false positive (SCA/Secret Scan): {str(e)}")
            raise

    def mark_all_as_false_positive_sast_dast(self):
        self.logger.info("Attempting to mark all vulnerabilities as false positive (SAST/DAST)")
        try:
            ActionUtils.click(self.driver, By.XPATH, self.three_dots, "Three Dots")
            ActionUtils.click(self.driver, By.XPATH, self.mark_all_as_false_positive1, "Mark All as False Positive")
            ActionUtils.confirm_alert(self.driver)
            self.logger.info("All vulnerabilities marked as false positive")
        except Exception as e:
            self.logger.error(f"Failed to mark all vulnerabilities as false positive (SAST/DAST): {str(e)}")
            raise

    def verify_status(self):
        self.logger.info("Verifying that the vulnerability status is closed")
        try:
            ActionUtils.click(self.driver, By.XPATH, self.status, "Status")
            status = ActionUtils.get_element_text(self.driver, By.CSS_SELECTOR, self.vul_status, "Vul Status").strip()
            assert status == "Closed", f"Expected status: Closed, but found: {status}"
            self.logger.info("Vulnerability status verified as closed")
        except Exception as e:
            self.logger.error(f"Failed to verify that the vulnerability status is closed: {str(e)}")
            raise

    def verify_status_accepted_risk(self):
        self.logger.info("Verifying that the vulnerability status is accepted risk")
        try:
            ActionUtils.click(self.driver, By.XPATH, self.status1, "Status")
            status = ActionUtils.get_element_text(self.driver, By.XPATH, self.vul_status1, "Status1").strip()
            assert status == "Accepted Risk", f"Expected status: Accepted Risk, but found: {status}"
            background_color = ActionUtils.get_element_css_value(self.driver, By.XPATH, self.vul_status1, "color", "BG_Color")
            assert background_color == "rgba(255, 255, 255, 1)", f"Expected background color: rgba(255, 255, 255, 1), but found: {background_color}"
            self.logger.info("Vulnerability status verified as accepted risk with correct color (orange)")
        except Exception as e:
            self.logger.error(f"Failed to verify that the vulnerability status is accepted risk: {str(e)}")
            raise

    def verify_status_in_progress(self):
        self.logger.info("Verifying that the vulnerability status is in progress")
        try:
            ActionUtils.click(self.driver, By.XPATH, self.status1, "Status")
            status = ActionUtils.get_element_text(self.driver, By.XPATH, self.vul_status1, "Status1").strip()
            assert status == "In Progress", f"Expected status: In Progress, but found: {status}"
            self.logger.info("Vulnerability status verified as in progress")
        except Exception as e:
            self.logger.error(f"Failed to verify that the vulnerability status is in progress: {str(e)}")
            raise

    def verify_status_pending(self):
        self.logger.info("Verifying that the vulnerability status is pending")
        try:
            ActionUtils.click(self.driver, By.XPATH, self.status1, "Status")
            status = ActionUtils.get_element_text(self.driver, By.XPATH, self.vul_status1, "Status1").strip()
            assert status == "Pending", f"Expected status: Pending, but found: {status}"
            self.logger.info("Vulnerability status verified as pending")
        except Exception as e:
            self.logger.error(f"Failed to verify that the vulnerability status is pending: {str(e)}")
            raise
